"use client"

import BeamsBackground from "../components/kokonutui/beams-background"

export default function SyntheticV0PageForDeployment() {
  return <BeamsBackground />
}