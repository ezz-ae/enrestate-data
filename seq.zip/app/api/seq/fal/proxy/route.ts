import * as route from "@fal-ai/server-proxy"


export const POST = route.responsePassthrough
export const GET = route.responsePassthrough
