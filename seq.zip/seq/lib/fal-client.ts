import { fal } from "@fal-ai/client"

fal.config({
  proxyUrl: "/api/seq/fal/proxy",
})

export { fal }
